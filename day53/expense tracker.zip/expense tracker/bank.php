<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>UPI Section</title>

  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

  <style>
    body { background: #f8f9fa; }
    .card { border-radius: 15px; }
    .summary-card {
      color: #fff; padding: 20px; border-radius: 15px;
    }
    .upi-income { background: linear-gradient(45deg, #84fab0, #8fd3f4); }
    .upi-expense { background: linear-gradient(45deg, #ff6a88, #ff99ac); }
    .upi-balance { background: linear-gradient(45deg, #43e97b, #38f9d7); }
    .qr-box img { border: 5px solid #f1f1f1; border-radius: 10px; }
  </style>
</head>
<body>

<div class="container my-4">
  <h2 class="mb-4">📱 UPI Section</h2>

  <!-- Transaction Summary -->
  <div class="row g-3 mb-4">
    <div class="col-md-4">
      <div class="summary-card upi-income">
        <h6>Total UPI Income</h6>
        <h3>₹ 25,000</h3>
      </div>
    </div>
    <div class="col-md-4">
      <div class="summary-card upi-expense">
        <h6>Total UPI Expense</h6>
        <h3>₹ 12,500</h3>
      </div>
    </div>
    <div class="col-md-4">
      <div class="summary-card upi-balance">
        <h6>Net UPI Balance</h6>
        <h3>₹ 12,500</h3>
      </div>
    </div>
  </div>

  <!-- Linked UPI Accounts -->
  <div class="card shadow-sm mb-4">
    <div class="card-body">
      <h5 class="card-title">Linked UPI Accounts</h5>
      <ul class="list-group" id="upiList">
        <li class="list-group-item d-flex justify-content-between align-items-center">
          atharva@upi 
          <button class="btn btn-sm btn-danger" onclick="removeUPI(this)">Remove</button>
        </li>
        <li class="list-group-item d-flex justify-content-between align-items-center">
          demo@oksbi 
          <button class="btn btn-sm btn-danger" onclick="removeUPI(this)">Remove</button>
        </li>
      </ul>
      <div class="mt-3 d-flex">
        <input type="text" id="newUPI" class="form-control me-2" placeholder="Enter new UPI ID">
        <button class="btn btn-success" onclick="addUPI()">Add</button>
      </div>
    </div>
  </div>

  <!-- Quick Scan & Pay -->
  <div class="card shadow-sm">
    <div class="card-body">
      <h5 class="card-title">Quick Scan & Pay</h5>
      <div class="row g-4">
        <div class="col-md-4 text-center qr-box">
          <h6>atharva@upi</h6>
          <img src="https://api.qrserver.com/v1/create-qr-code/?data=upi://pay?pa=atharva@upi&size=150x150" alt="QR Code">
        </div>
        <div class="col-md-4 text-center qr-box">
          <h6>demo@oksbi</h6>
          <img src="https://api.qrserver.com/v1/create-qr-code/?data=upi://pay?pa=demo@oksbi&size=150x150" alt="QR Code">
        </div>
      </div>
    </div>
  </div>

</div>

<!-- Scripts -->
<script>
  function addUPI() {
    const upiInput = document.getElementById("newUPI");
    const upiValue = upiInput.value.trim();
    if (upiValue !== "") {
      const li = document.createElement("li");
      li.className = "list-group-item d-flex justify-content-between align-items-center";
      li.innerHTML = upiValue + ' <button class="btn btn-sm btn-danger" onclick="removeUPI(this)">Remove</button>';
      document.getElementById("upiList").appendChild(li);
      upiInput.value = "";
    }
  }

  function removeUPI(button) {
    button.parentElement.remove();
  }
</script>

</body>
</html>
